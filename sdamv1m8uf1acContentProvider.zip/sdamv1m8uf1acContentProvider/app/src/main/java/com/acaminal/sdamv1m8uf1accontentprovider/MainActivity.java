package com.acaminal.sdamv1m8uf1accontentprovider;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.provider.UserDictionary;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @SuppressLint("Range")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String[] projection = new String[]{
                ContactsContract.Contacts._ID,
                ContactsContract.Contacts.DISPLAY_NAME,
                ContactsContract.Contacts.HAS_PHONE_NUMBER
        };

        String where = null;
        String[] whereArgs = null;

        String sortOrder = ContactsContract.Contacts.DISPLAY_NAME + " COLLATE LOCALIZED ASC"; // Corregido: añadido espacio antes de COLLATE

        Cursor c = getContentResolver().query(
                ContactsContract.Contacts.CONTENT_URI,
                projection,
                where,
                whereArgs,
                sortOrder
        );

        if (c == null) {
            // Manejar el error aquí
        } else if (c.getCount() < 1) {
            Toast.makeText(this, "No hay datos", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "OK", Toast.LENGTH_SHORT).show();
        }

        String contactID, nomContacte, telefon = null, email = null;

        while (c.moveToNext()) {
            contactID = c.getString(c.getColumnIndex(ContactsContract.Contacts._ID));
            nomContacte = c.getString(c.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
            String hasPhone = c.getString(c.getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER));

            if ("1".equals(hasPhone)) {
                Cursor phones = getContentResolver().query(
                        ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                        null,
                        ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = " + contactID,
                        null,
                        null);

                if (phones != null) {
                    while (phones.moveToNext()) {
                        telefon = phones.getString(phones.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                    }
                    phones.close();
                }
            }

            Cursor emails = getContentResolver().query(
                    ContactsContract.CommonDataKinds.Email.CONTENT_URI,
                    null,
                    ContactsContract.CommonDataKinds.Email.CONTACT_ID + " = " + contactID,
                    null,
                    null);

            if (emails != null) {
                while (emails.moveToNext()) {
                    email = emails.getString(emails.getColumnIndex(ContactsContract.CommonDataKinds.Email.DATA));
                }
                emails.close();
            }

            Toast.makeText(this, "id: " + contactID + "\n" + "Nom: " + nomContacte +
                    "\n Telefon: " + telefon + "\n email: " + email, Toast.LENGTH_SHORT).show();
        }

        c.close();
    }

    @Override
    public ContentResolver getContentResolver() {
        ContentValues Valors = new ContentValues();

        Valors.put(UserDictionary.Words.APP_ID, "com.android.ioc");
        Valors.put(UserDictionary.Words.LOCALE, "es_ES");
        Valors.put(UserDictionary.Words.WORD, "Hospitalet");
        Valors.put(UserDictionary.Words.FREQUENCY, "100");

        getContentResolver().insert(UserDictionary.Words.CONTENT_URI, Valors);
        return super.getContentResolver();
    }
}